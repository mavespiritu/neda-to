<?php

namespace markavespiritu\user\models;

use Yii;

/**
 * This is the model class for table "tbldesignation".
 *
 * @property integer $DESIGNATION_ID
 * @property string $DESIGNATION_M
 *
 * @property UserInfo[] $userInfos
 */
class Designation extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'tbldesignation';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['DESIGNATION_M'], 'string', 'max' => 100]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'DESIGNATION_ID' => 'Designation  ID',
            'DESIGNATION_M' => 'Designation  M',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUserInfos()
    {
        return $this->hasMany(UserInfo::className(), ['DESIGNATION' => 'DESIGNATION_ID']);
    }
}
