<?php



use yii\db\Migration;
use yii\db\Schema;

class m160824_104133_fix_emp_n_field extends Migration
{
    public function up()
    {
        $this->alterColumn('{{%user_info}}', 'EMP_N', Schema::TYPE_STRING . '(100)');
    }

    public function down()
    {
        $this->alterColumn('{{%user_info}}', 'EMP_N', Schema::TYPE_INTEGER);
    }
}
