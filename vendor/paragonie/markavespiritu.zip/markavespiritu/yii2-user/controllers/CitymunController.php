<?php


namespace markavespiritu\user\controllers;

use markavespiritu\user\models\Citymun;
use yii\helpers\ArrayHelper;

class CitymunController extends \yii\web\Controller
{

    /**
     * Returns all City/Municipalities on a certain Province.
     * @param string           $province     province_c     Province Code
     * @return Json {id:$citymun->citymun_c, name:$citymun->LGU_M}
     */
    public function actionCitymunList($province)
    {
        $citymuns = Citymun::find()->select(['citymun_c','citymun_m'])->where(['province_c'=>$province])->all();
        //$provinces = ArrayHelper::map($provinces,'province_c','citymun_m');
        $arr = [];
        $arr[] = ['id'=>'','text'=>''];
        foreach($citymuns as $citymun){
            $arr[] = ['id'=>$citymun->citymun_c,'text'=>$citymun->citymun_m];
        }
        \Yii::$app->response->format = 'json';
        return $arr;
    }

}


