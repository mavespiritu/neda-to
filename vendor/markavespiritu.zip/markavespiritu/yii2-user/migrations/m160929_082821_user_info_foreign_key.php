<?php

use yii\db\Migration;

class m160929_082821_user_info_foreign_key extends Migration
{
    public function up()
    {
        $this->execute('SET foreign_key_checks = 0');
        $this->dropForeignKey('fk_tblprovince_2104_00','{{%user_info}}');
        $this->dropForeignKey('fk_tblregion_2104_01','{{%user_info}}');
        $this->execute('SET foreign_key_checks = 1;');
    }

    public function down()
    {
        $this->execute('SET foreign_key_checks = 0');
        $this->addForeignKey('fk_tblprovince_2104_00','{{%user_info}}', 'PROVINCE_C', '{{%tblprovince}}', 'province_c', 'CASCADE', 'CASCADE' );
        $this->addForeignKey('fk_tblregion_2104_01','{{%user_info}}', 'REGION_C', '{{%tblregion}}', 'region_c', 'CASCADE', 'CASCADE' );
        $this->execute('SET foreign_key_checks = 1;');
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
