<?php

namespace tests\codeception\_fixtures;

use yii\test\ActiveFixture;

class ProfileFixture extends ActiveFixture
{
    public $modelClass = 'markavespiritu\user\models\Profile';
}
