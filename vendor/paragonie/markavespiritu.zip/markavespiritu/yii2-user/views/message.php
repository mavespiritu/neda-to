<?php



/**
 * @var yii\web\View 			$this
 * @var markavespiritu\user\Module 	$module
 */

$this->title = $title;

?>

<?= $this->render('/_alert', [
    'module' => $module,
]) ?>
