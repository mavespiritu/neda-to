<?php

namespace tests\codeception\_fixtures;

use yii\test\ActiveFixture;

class TokenFixture extends ActiveFixture
{
    public $modelClass = 'markavespiritu\user\models\Token';
}
