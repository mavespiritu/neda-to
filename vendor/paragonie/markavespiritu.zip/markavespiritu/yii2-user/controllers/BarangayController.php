<?php


namespace markavespiritu\user\controllers;

use markavespiritu\user\models\Citymun;
use markavespiritu\user\models\Barangay;
use yii\helpers\ArrayHelper;

class BarangayController extends \yii\web\Controller
{

    /**
     * Returns all Barangays on a certain City/Municipalities.
     * @param string           $province     province_c     Province Code
     * @return Json {id:$barangay->barangay_c, text:$barangay->barangay_m}
     */
    public function actionBarangayList($citymun,$province)
    {
		$params = ['province_c'=>$province, 'citymun_c'=>$citymun];
		if($province == '39' && $citymun == '00'){
			unset($params['citymun_c']);
		}
		
        $barangays = Barangay::find()->select(['barangay_c','barangay_m'])->where($params)->all();
        //$provinces = ArrayHelper::map($provinces,'province_c','citymun_m');
        $arr = [];
        $arr[] = ['id'=>'','text'=>''];
        foreach($barangays as $barangay){
            $arr[] = ['id'=>$barangay->barangay_c,'text'=>$barangay->barangay_m];
        }
        \Yii::$app->response->format = 'json';
        return $arr;
    }

}


