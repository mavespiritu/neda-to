<?php


namespace markavespiritu\user\controllers;

use markavespiritu\user\models\Province;
use yii\helpers\ArrayHelper;

class ProvinceController extends \yii\web\Controller
{

    /**
     * Returns all Provinces on a certain Region.
     * @param string           $region     REGION_C     
     * @return Json {id:$province->province_c, name:$province->province_m}
     */
    public function actionProvinceList($region)
    {
        $provinces = Province::find()->select(['province_c','province_m'])->where(['region_c'=>$region])->all();
        //$provinces = ArrayHelper::map($provinces,'province_c','province_m');
        $arr = [];
        $arr[] = ['id'=>'','text'=>''];
        foreach($provinces as $province){
            $arr[] = ['id'=>$province->province_c,'text'=>$province->province_m];
        }
        \Yii::$app->response->format = 'json';
        return $arr;
    }

}