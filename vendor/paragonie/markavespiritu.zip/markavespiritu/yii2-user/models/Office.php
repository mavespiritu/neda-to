<?php

namespace markavespiritu\user\models;

use Yii;

/**
 * This is the model class for table "tbloffice".
 *
 * @property integer $OFFICE_C
 * @property string $OFFICE_M
 *
 * @property UserInfo[] $userInfos
 */
class Office extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'tbloffice';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['title', 'abbreviation'], 'string', 'max' => 50]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Title',
            'abbreviation' => 'Abbreviation',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUserInfos()
    {
        return $this->hasMany(UserInfo::className(), ['OFFICE_C' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSections()
    {
        return $this->hasMany(Section::className(), ['office_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUnits()
    {
        return $this->hasMany(Unit::className(), ['office_id' => 'id']);
    }
}
