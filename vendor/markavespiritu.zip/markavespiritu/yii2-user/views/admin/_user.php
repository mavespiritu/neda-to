<?php

use kartik\select2\Select2;
use dosamigos\datepicker\DatePicker;

/**
 * @var yii\widgets\ActiveForm 		$form
 * @var markavespiritu\user\models\User 	$user
 */

$sectionsurl = \yii\helpers\Url::to(['section/section-list']);
$unitsurl = \yii\helpers\Url::to(['unit/unit-list']);
?>

<h4>User Details</h4>
<div class='row'>
    <div class='col-md-6 col-xs-12'>
        <?= $form->field($userinfo, 'EMP_N')->textInput(['placeholder'=>'Employee ID No.']); ?>
        
        <?= $form->field($userinfo, 'OFFICE_C')->widget(Select2::classname(), [
                'data' => $offices,
                'options' => ['placeholder' => 'Office','multiple' => false, 'class' => 'office-select'],
                'pluginOptions' => [
                    'allowClear' => true
                ],
                'pluginEvents'=>[
                'select2:select'=>'
                    function(){
                        var vals = this.value;
                        $.ajax({
                            url: "'.$sectionsurl.'",
                            data: {office:vals}
                            
                        }).done(function(result) {
                            var h;
                            $(".section-select").html("").select2({ data:result, theme:"krajee", width:"100%",placeholder:"Select Section", allowClear: true,});
                            $(".section-select").select2("val","");
                        });

                        $.ajax({
                            url: "'.$unitsurl.'",
                            data: {office:vals}
                            
                        }).done(function(result) {
                            var h;
                            $(".unit-select").html("").select2({ data:result, theme:"krajee", width:"100%",placeholder:"Select Unit", allowClear: true,});
                            $(".unit-select").select2("val","");
                        });
                    }'
                ]
            ]);
        ?>

        <?= $form->field($userinfo, 'SECTION_C')->widget(Select2::classname(), [
                'data' => $sections,
                'options' => ['placeholder' => 'Section','multiple' => false,'class'=>'section-select'],
                'pluginOptions' => [
                    'allowClear' => true
                ],
                'pluginEvents'=>[
                    'select2:select'=>'
                        function(){
                            var vals = this.value;
                            var vals2 = $(".office-select").val();
                            $.ajax({
                                url: "'.$unitsurl.'",
                                data: {office:vals2, section:vals}
                                
                            }).done(function(result) {
                                var h;
                                $(".unit-select").html("").select2({ data:result, theme:"krajee", width:"100%",placeholder:"Select Unit", allowClear: true,});
                                $(".unit-select").select2("val","");
                            });
                        }'
                ]
            ]);
        ?>

        <?= $form->field($userinfo, 'UNIT_C')->widget(Select2::classname(), [
                'data' => $units,
                'options' => ['placeholder' => 'Unit','multiple' => false ,'class'=>'unit-select'],
                'pluginOptions' => [
                    'allowClear' => true
                ],
            ]);
        ?>

        <?= $form->field($userinfo, 'POSITION_C')->textInput(); ?>
    </div>
    <div class='col-md-6 col-xs-12'>
        <?= $form->field($userinfo, 'FIRST_M')->textInput(['placeholder'=>'First Name']); ?>
        <?= $form->field($userinfo, 'MIDDLE_M')->textInput(['placeholder'=>'Middle Name']); ?>
        <?= $form->field($userinfo, 'LAST_M')->textInput(['placeholder'=>'Last Name']); ?>
        <?= $form->field($userinfo, 'SUFFIX')->textInput(['placeholder'=>'Suffix']); ?>
    </div>
</div>

<hr>
<h4>Account Details</h4>

<div class="row">

    <div class="col-md-6 col-xs-12">
        <?= $form->field($user, 'email')->textInput(['placeholder'=>'Email Address']); ?>

        <?= $form->field($user, 'username')->textInput(['placeholder'=>'Username']); ?>

        <?= $form->field($user, 'password')->passwordInput() ?>
    </div>
</div>


