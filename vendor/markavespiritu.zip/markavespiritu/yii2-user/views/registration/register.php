<?php



use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\web\JsExpression;
use dosamigos\datepicker\DatePicker;
use frontend\assets\AppAsset;

/**
 * @var yii\web\View              $this
 * @var markavespiritu\user\models\User $user
 * @var markavespiritu\user\Module      $module
 */

$this->title = Yii::t('user', 'Sign up');
$this->params['breadcrumbs'][] = $this->title;

$sectionsurl = \yii\helpers\Url::to(['section/section-list']);
$unitsurl = \yii\helpers\Url::to(['unit/unit-list']);

$asset = AppAsset::register($this);
?>
<div class="row">
    <div class="col-md-9 col-xs-12">
        <div class="fill"></div>
    </div>
    <div class="col-md-3 col-xs-12">
        <div class="row">
            <div class="col-md-1 col-xs-12"></div>
            <div class="col-md-10 col-xs-12">
            <br>
            <h4 class="text-center">Registration Form</h4>
            <p class="text-center">Please enter your credentials</p>
                <?php $form = ActiveForm::begin([
                    'id'                     => 'registration-form',
                    'enableAjaxValidation'   => true,
                    'enableClientValidation' => false,
                ]); ?>
                <p class="text-right">* Required fields</p>
                <h4>User Details</h4>

                <?= $form->field($model, 'EMP_N')->textInput(); ?>

                <div class="row">
                    <div class="col-md-6 col-xs-12">
                        <?= $form->field($model, 'FIRST_M')->textInput(); ?>   
                    </div>
                    <div class="col-md-6 col-xs-12">
                        <?= $form->field($model, 'LAST_M')->textInput(); ?>
                    </div>
                </div>

                <?= $form->field($model, 'OFFICE_C')->widget(Select2::classname(), [
                                'data' => $offices,
                                'options' => ['placeholder' => 'Select Division','multiple' => false, 'class' => 'office-select'],
                                'pluginOptions' => [
                                    'allowClear' => true
                                ],
                                'pluginEvents'=>[
                                'select2:select'=>'
                                    function(){
                                        var vals = this.value;

                                        $.ajax({
                                            url: "'.$unitsurl.'",
                                            data: {office:vals}
                                            
                                        }).done(function(result) {
                                            var h;
                                            $(".unit-select").html("").select2({ data:result, theme:"krajee", width:"100%",placeholder:"Select Unit", allowClear: true,});
                                            $(".unit-select").select2("val","");
                                        });
                                    }'

                    ]
                    ]);
                ?>

                <?= $form->field($model, 'UNIT_C')->widget(Select2::classname(), [
                        'data' => $units,
                        'options' => ['placeholder' => 'Select Unit','multiple' => false ,'class'=>'unit-select'],
                        'pluginOptions' => [
                            'allowClear' => false
                        ],
                    ]);
                ?>

                <?= $form->field($model, 'POSITION_C')->textInput(); ?>

                <hr style="opacity: 0.5;">

                <h4>Account Details</h4>

                <?= $form->field($model, 'email')->textInput(); ?>

                <?= $form->field($model, 'username')->textInput(); ?>

                <?php if ($module->enableGeneratingPassword == false): ?>
                    <?= $form->field($model, 'password')->passwordInput() ?>
                <?php endif ?>

                <?= Html::submitButton(Yii::t('user', 'Sign up'), ['class' => 'btn btn-success btn-block']) ?>

                <?php ActiveForm::end(); ?>
        <br>
        <p class="text-center">
            <?= Html::a(Yii::t('user', 'Already registered? Sign in!'), ['/user/security/login']) ?>
        </p>
        </div>
        <div class="col-md-1 col-xs-12"></div>
    </div>
</div>

<style>
.centered {
    text-align: center;
    font-size: 0;
}
.centered > div {
   float: none;
   display: inline-block;
   text-align: left;
}

.fill {
    display: flex;
    justify-content: center;
    align-items: center;
    overflow: hidden;
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100vh;
    width: 100%;
    background: url(<?= $asset->baseUrl.'/images/neda.jpg' ?>) no-repeat center fixed;
    background-size: cover;
}

.content{
    margin: 0 !important;
    padding: 0 !important;
}
</style>
