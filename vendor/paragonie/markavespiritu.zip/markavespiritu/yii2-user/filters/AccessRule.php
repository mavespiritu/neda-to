<?php



namespace markavespiritu\user\filters;

/**
 * Access rule class for simpler RBAC.
 * @see http://yii2-user.dmeroff.ru/docs/custom-access-control
 * @author Dmitry Erofeev <dmeroff@gmail.com>
 */
class AccessRule extends \yii\filters\AccessRule
{
    /**
     * @inheritdoc
     * */
    protected function matchRole($user)
    {
        if (empty($this->roles)) {
            return true;
        }

        foreach ($this->roles as $role) {
            if ($role === '?') {
                if (\Yii::$app->user->isGuest) {
                    return true;
                }
            } elseif ($role === '@') {
                if (!\Yii::$app->user->isGuest) {
                    return true;
                }
            } elseif ($role === 'admin') {
                if (!\Yii::$app->user->isGuest && \Yii::$app->user->identity->isAdmin) {
                    return true;
                }
            } elseif ($role === 'Administrator') {
                if (\Yii::$app->user->can('Administrator')) {
                    return true;
                }
			} elseif ($role === 'RegionalAdministrator') {
                if (\Yii::$app->user->can('RegionalAdministrator')) {
                    return true;
                }
			}
        }

        return false;
    }
}