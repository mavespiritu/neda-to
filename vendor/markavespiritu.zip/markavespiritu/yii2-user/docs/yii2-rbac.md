# Powerful RBAC with Yii2-rbac

Yii2-rbac is another extension for Yii2 which provides CRUD operations for RBAC
and also is highly integrated with Yii2-user and allows to assign roles and
permissions to users.

## Installation

Installation instructions are located in [Yii2-rbac repository](https://github.com/markavespiritu/yii2-rbac).

## Usage

After installing Yii2-rbac you will be able to manage auth items (roles and
permissions) and assign them to users on update page.
